export default [
  require("/home/ubuntu/ai-automation-docusaurus/node_modules/infima/dist/css/default/default.css"),
  require("/home/ubuntu/ai-automation-docusaurus/node_modules/@docusaurus/theme-classic/lib/prism-include-languages"),
  require("/home/ubuntu/ai-automation-docusaurus/node_modules/@docusaurus/theme-classic/lib/nprogress"),
  require("/home/ubuntu/ai-automation-docusaurus/src/css/custom.css"),
];
