import React from 'react';
import ComponentCreator from '@docusaurus/ComponentCreator';

export default [
  {
    path: '/blog',
    component: ComponentCreator('/blog', '1b9'),
    exact: true
  },
  {
    path: '/blog/archive',
    component: ComponentCreator('/blog/archive', '182'),
    exact: true
  },
  {
    path: '/blog/authors',
    component: ComponentCreator('/blog/authors', '0b7'),
    exact: true
  },
  {
    path: '/blog/authors/all-sebastien-lorber-articles',
    component: ComponentCreator('/blog/authors/all-sebastien-lorber-articles', 'dea'),
    exact: true
  },
  {
    path: '/blog/authors/yangshun',
    component: ComponentCreator('/blog/authors/yangshun', '7c6'),
    exact: true
  },
  {
    path: '/blog/mdx-blog-post',
    component: ComponentCreator('/blog/mdx-blog-post', 'e9f'),
    exact: true
  },
  {
    path: '/blog/tags',
    component: ComponentCreator('/blog/tags', '287'),
    exact: true
  },
  {
    path: '/blog/tags/docusaurus',
    component: ComponentCreator('/blog/tags/docusaurus', '85c'),
    exact: true
  },
  {
    path: '/docs',
    component: ComponentCreator('/docs', '7d2'),
    routes: [
      {
        path: '/docs',
        component: ComponentCreator('/docs', '066'),
        routes: [
          {
            path: '/docs',
            component: ComponentCreator('/docs', 'a98'),
            routes: [
              {
                path: '/docs/enterprise-governance',
                component: ComponentCreator('/docs/enterprise-governance', '3a4'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/implementation-roadmap',
                component: ComponentCreator('/docs/implementation-roadmap', 'e0f'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/intro',
                component: ComponentCreator('/docs/intro', '61d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/metrics',
                component: ComponentCreator('/docs/metrics', 'ec1'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/module1',
                component: ComponentCreator('/docs/module1', '70c'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/prerequisites',
                component: ComponentCreator('/docs/prerequisites', '665'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/resources',
                component: ComponentCreator('/docs/resources', '9f3'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/security-integration',
                component: ComponentCreator('/docs/security-integration', '92d'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/setup',
                component: ComponentCreator('/docs/setup', '054'),
                exact: true,
                sidebar: "tutorialSidebar"
              },
              {
                path: '/docs/troubleshooting',
                component: ComponentCreator('/docs/troubleshooting', 'e02'),
                exact: true,
                sidebar: "tutorialSidebar"
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '/',
    component: ComponentCreator('/', 'e5f'),
    exact: true
  },
  {
    path: '*',
    component: ComponentCreator('*'),
  },
];
